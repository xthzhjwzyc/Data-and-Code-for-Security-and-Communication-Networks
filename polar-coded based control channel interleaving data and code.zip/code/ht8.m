function [] = ht(j,a)
j=[0,1,2,3];
a=5*4*1/2-j;
stem(j,a,'.');
end

