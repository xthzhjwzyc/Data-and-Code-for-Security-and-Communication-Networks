function [] = ht(j,a)
j=[0,1,2,3];
a=(6+4)*3*1/2-[4-(j+1)];
stem(j,a,'.');
end

