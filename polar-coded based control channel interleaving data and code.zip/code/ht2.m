function [] = ht(j,a)
j=[0,1,2,3,4];
a=(6+5)*2*1/2-[5-(j+1)];
stem(j,a,'.');
xlabel('j');
ylabel('a')
end

