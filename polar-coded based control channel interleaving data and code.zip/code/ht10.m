function [] = ht(i,a)
i=[0,1];
a=[6-(i+1)+4-(i+1)]*3*1/2;
stem(i,a,'.');
end

