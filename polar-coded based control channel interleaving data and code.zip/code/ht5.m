function [] = ht(i,a)
i=[0,1,2,3,4];
p=6;
a=(1+p-1+4+1)*2*1/2-[5-(i+1)];
stem(i,a,'.');
end

