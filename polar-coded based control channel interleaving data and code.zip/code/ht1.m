function [] = ht(j,a)
j=[0,1,2,3,4,5];
a=j;
stem(j,a,'.');
end

