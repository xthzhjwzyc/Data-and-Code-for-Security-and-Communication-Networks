function [] = ht(i,a)
i=[0,1,2,3];
p=6;
a=(1+p-1+4)*3*1/2-[4-(i+1)];
stem(i,a,'.');
end

